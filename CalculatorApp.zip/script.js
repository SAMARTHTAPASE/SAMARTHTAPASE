
const inputField = document.getElementById('resultDisplay');
const historyField = document.getElementById('historyDisplay');

function appendToInput(value) {
  if (inputField.innerText === '0') inputField.innerText = '';
  inputField.innerText += value;
  playTapSound();
}

function clearInput() {
  inputField.innerText = '0';
  historyField.innerText = '';
  playTapSound();
}

function eraseLast() {
  inputField.innerText = inputField.innerText.slice(0, -1) || '0';
  playTapSound();
}

function calculateResult() {
  try {
    const result = eval(inputField.innerText.replace(/÷/g, '/').replace(/×/g, '*'));
    historyField.innerText = inputField.innerText + ' =';
    inputField.innerText = result;
    speakResult(result);
  } catch {
    inputField.innerText = 'Error';
  }
}

function playTapSound() {
  const sound = document.getElementById('tapSound');
  sound.currentTime = 0;
  sound.play();
}

function speakResult(result) {
  const speech = new SpeechSynthesisUtterance("The result is " + result);
  window.speechSynthesis.speak(speech);
}
